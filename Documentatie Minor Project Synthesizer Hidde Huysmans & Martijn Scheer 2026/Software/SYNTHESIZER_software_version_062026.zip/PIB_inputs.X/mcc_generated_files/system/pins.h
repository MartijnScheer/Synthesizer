/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  1.1.0
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H_INCLUDED
#define PINS_H_INCLUDED

#include <avr/io.h>
#include "./port.h"

//get/set DAC aliases
#define DAC_SetHigh() do { PORTD_OUTSET = 0x40; } while(0)
#define DAC_SetLow() do { PORTD_OUTCLR = 0x40; } while(0)
#define DAC_Toggle() do { PORTD_OUTTGL = 0x40; } while(0)
#define DAC_GetValue() (VPORTD.IN & (0x1 << 6))
#define DAC_SetDigitalInput() do { PORTD_DIRCLR = 0x40; } while(0)
#define DAC_SetDigitalOutput() do { PORTD_DIRSET = 0x40; } while(0)
#define DAC_SetPullUp() do { PORTD_PIN6CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define DAC_ResetPullUp() do { PORTD_PIN6CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define DAC_SetInverted() do { PORTD_PIN6CTRL  |= PORT_INVEN_bm; } while(0)
#define DAC_ResetInverted() do { PORTD_PIN6CTRL  &= ~PORT_INVEN_bm; } while(0)
#define DAC_DisableInterruptOnChange() do { PORTD.PIN6CTRL = (PORTD.PIN6CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define DAC_EnableInterruptForBothEdges() do { PORTD.PIN6CTRL = (PORTD.PIN6CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define DAC_EnableInterruptForRisingEdge() do { PORTD.PIN6CTRL = (PORTD.PIN6CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define DAC_EnableInterruptForFallingEdge() do { PORTD.PIN6CTRL = (PORTD.PIN6CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define DAC_DisableDigitalInputBuffer() do { PORTD.PIN6CTRL = (PORTD.PIN6CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define DAC_EnableInterruptForLowLevelSensing() do { PORTD.PIN6CTRL = (PORTD.PIN6CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PD6_SetInterruptHandler DAC_SetInterruptHandler

//get/set OCT1_C aliases
#define OCT1_C_SetHigh() do { PORTA_OUTSET = 0x4; } while(0)
#define OCT1_C_SetLow() do { PORTA_OUTCLR = 0x4; } while(0)
#define OCT1_C_Toggle() do { PORTA_OUTTGL = 0x4; } while(0)
#define OCT1_C_GetValue() (VPORTA.IN & (0x1 << 2))
#define OCT1_C_SetDigitalInput() do { PORTA_DIRCLR = 0x4; } while(0)
#define OCT1_C_SetDigitalOutput() do { PORTA_DIRSET = 0x4; } while(0)
#define OCT1_C_SetPullUp() do { PORTA_PIN2CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT1_C_ResetPullUp() do { PORTA_PIN2CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT1_C_SetInverted() do { PORTA_PIN2CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT1_C_ResetInverted() do { PORTA_PIN2CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT1_C_DisableInterruptOnChange() do { PORTA.PIN2CTRL = (PORTA.PIN2CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT1_C_EnableInterruptForBothEdges() do { PORTA.PIN2CTRL = (PORTA.PIN2CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT1_C_EnableInterruptForRisingEdge() do { PORTA.PIN2CTRL = (PORTA.PIN2CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT1_C_EnableInterruptForFallingEdge() do { PORTA.PIN2CTRL = (PORTA.PIN2CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT1_C_DisableDigitalInputBuffer() do { PORTA.PIN2CTRL = (PORTA.PIN2CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT1_C_EnableInterruptForLowLevelSensing() do { PORTA.PIN2CTRL = (PORTA.PIN2CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PA2_SetInterruptHandler OCT1_C_SetInterruptHandler

//get/set OCT1_Db aliases
#define OCT1_Db_SetHigh() do { PORTA_OUTSET = 0x8; } while(0)
#define OCT1_Db_SetLow() do { PORTA_OUTCLR = 0x8; } while(0)
#define OCT1_Db_Toggle() do { PORTA_OUTTGL = 0x8; } while(0)
#define OCT1_Db_GetValue() (VPORTA.IN & (0x1 << 3))
#define OCT1_Db_SetDigitalInput() do { PORTA_DIRCLR = 0x8; } while(0)
#define OCT1_Db_SetDigitalOutput() do { PORTA_DIRSET = 0x8; } while(0)
#define OCT1_Db_SetPullUp() do { PORTA_PIN3CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT1_Db_ResetPullUp() do { PORTA_PIN3CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT1_Db_SetInverted() do { PORTA_PIN3CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT1_Db_ResetInverted() do { PORTA_PIN3CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT1_Db_DisableInterruptOnChange() do { PORTA.PIN3CTRL = (PORTA.PIN3CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT1_Db_EnableInterruptForBothEdges() do { PORTA.PIN3CTRL = (PORTA.PIN3CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT1_Db_EnableInterruptForRisingEdge() do { PORTA.PIN3CTRL = (PORTA.PIN3CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT1_Db_EnableInterruptForFallingEdge() do { PORTA.PIN3CTRL = (PORTA.PIN3CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT1_Db_DisableDigitalInputBuffer() do { PORTA.PIN3CTRL = (PORTA.PIN3CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT1_Db_EnableInterruptForLowLevelSensing() do { PORTA.PIN3CTRL = (PORTA.PIN3CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PA3_SetInterruptHandler OCT1_Db_SetInterruptHandler

//get/set OCT1_D aliases
#define OCT1_D_SetHigh() do { PORTA_OUTSET = 0x10; } while(0)
#define OCT1_D_SetLow() do { PORTA_OUTCLR = 0x10; } while(0)
#define OCT1_D_Toggle() do { PORTA_OUTTGL = 0x10; } while(0)
#define OCT1_D_GetValue() (VPORTA.IN & (0x1 << 4))
#define OCT1_D_SetDigitalInput() do { PORTA_DIRCLR = 0x10; } while(0)
#define OCT1_D_SetDigitalOutput() do { PORTA_DIRSET = 0x10; } while(0)
#define OCT1_D_SetPullUp() do { PORTA_PIN4CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT1_D_ResetPullUp() do { PORTA_PIN4CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT1_D_SetInverted() do { PORTA_PIN4CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT1_D_ResetInverted() do { PORTA_PIN4CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT1_D_DisableInterruptOnChange() do { PORTA.PIN4CTRL = (PORTA.PIN4CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT1_D_EnableInterruptForBothEdges() do { PORTA.PIN4CTRL = (PORTA.PIN4CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT1_D_EnableInterruptForRisingEdge() do { PORTA.PIN4CTRL = (PORTA.PIN4CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT1_D_EnableInterruptForFallingEdge() do { PORTA.PIN4CTRL = (PORTA.PIN4CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT1_D_DisableDigitalInputBuffer() do { PORTA.PIN4CTRL = (PORTA.PIN4CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT1_D_EnableInterruptForLowLevelSensing() do { PORTA.PIN4CTRL = (PORTA.PIN4CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PA4_SetInterruptHandler OCT1_D_SetInterruptHandler

//get/set OCT1_Eb aliases
#define OCT1_Eb_SetHigh() do { PORTA_OUTSET = 0x20; } while(0)
#define OCT1_Eb_SetLow() do { PORTA_OUTCLR = 0x20; } while(0)
#define OCT1_Eb_Toggle() do { PORTA_OUTTGL = 0x20; } while(0)
#define OCT1_Eb_GetValue() (VPORTA.IN & (0x1 << 5))
#define OCT1_Eb_SetDigitalInput() do { PORTA_DIRCLR = 0x20; } while(0)
#define OCT1_Eb_SetDigitalOutput() do { PORTA_DIRSET = 0x20; } while(0)
#define OCT1_Eb_SetPullUp() do { PORTA_PIN5CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT1_Eb_ResetPullUp() do { PORTA_PIN5CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT1_Eb_SetInverted() do { PORTA_PIN5CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT1_Eb_ResetInverted() do { PORTA_PIN5CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT1_Eb_DisableInterruptOnChange() do { PORTA.PIN5CTRL = (PORTA.PIN5CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT1_Eb_EnableInterruptForBothEdges() do { PORTA.PIN5CTRL = (PORTA.PIN5CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT1_Eb_EnableInterruptForRisingEdge() do { PORTA.PIN5CTRL = (PORTA.PIN5CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT1_Eb_EnableInterruptForFallingEdge() do { PORTA.PIN5CTRL = (PORTA.PIN5CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT1_Eb_DisableDigitalInputBuffer() do { PORTA.PIN5CTRL = (PORTA.PIN5CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT1_Eb_EnableInterruptForLowLevelSensing() do { PORTA.PIN5CTRL = (PORTA.PIN5CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PA5_SetInterruptHandler OCT1_Eb_SetInterruptHandler

//get/set OCT1_E aliases
#define OCT1_E_SetHigh() do { PORTA_OUTSET = 0x40; } while(0)
#define OCT1_E_SetLow() do { PORTA_OUTCLR = 0x40; } while(0)
#define OCT1_E_Toggle() do { PORTA_OUTTGL = 0x40; } while(0)
#define OCT1_E_GetValue() (VPORTA.IN & (0x1 << 6))
#define OCT1_E_SetDigitalInput() do { PORTA_DIRCLR = 0x40; } while(0)
#define OCT1_E_SetDigitalOutput() do { PORTA_DIRSET = 0x40; } while(0)
#define OCT1_E_SetPullUp() do { PORTA_PIN6CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT1_E_ResetPullUp() do { PORTA_PIN6CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT1_E_SetInverted() do { PORTA_PIN6CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT1_E_ResetInverted() do { PORTA_PIN6CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT1_E_DisableInterruptOnChange() do { PORTA.PIN6CTRL = (PORTA.PIN6CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT1_E_EnableInterruptForBothEdges() do { PORTA.PIN6CTRL = (PORTA.PIN6CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT1_E_EnableInterruptForRisingEdge() do { PORTA.PIN6CTRL = (PORTA.PIN6CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT1_E_EnableInterruptForFallingEdge() do { PORTA.PIN6CTRL = (PORTA.PIN6CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT1_E_DisableDigitalInputBuffer() do { PORTA.PIN6CTRL = (PORTA.PIN6CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT1_E_EnableInterruptForLowLevelSensing() do { PORTA.PIN6CTRL = (PORTA.PIN6CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PA6_SetInterruptHandler OCT1_E_SetInterruptHandler

//get/set OCT1_F aliases
#define OCT1_F_SetHigh() do { PORTA_OUTSET = 0x80; } while(0)
#define OCT1_F_SetLow() do { PORTA_OUTCLR = 0x80; } while(0)
#define OCT1_F_Toggle() do { PORTA_OUTTGL = 0x80; } while(0)
#define OCT1_F_GetValue() (VPORTA.IN & (0x1 << 7))
#define OCT1_F_SetDigitalInput() do { PORTA_DIRCLR = 0x80; } while(0)
#define OCT1_F_SetDigitalOutput() do { PORTA_DIRSET = 0x80; } while(0)
#define OCT1_F_SetPullUp() do { PORTA_PIN7CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT1_F_ResetPullUp() do { PORTA_PIN7CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT1_F_SetInverted() do { PORTA_PIN7CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT1_F_ResetInverted() do { PORTA_PIN7CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT1_F_DisableInterruptOnChange() do { PORTA.PIN7CTRL = (PORTA.PIN7CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT1_F_EnableInterruptForBothEdges() do { PORTA.PIN7CTRL = (PORTA.PIN7CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT1_F_EnableInterruptForRisingEdge() do { PORTA.PIN7CTRL = (PORTA.PIN7CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT1_F_EnableInterruptForFallingEdge() do { PORTA.PIN7CTRL = (PORTA.PIN7CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT1_F_DisableDigitalInputBuffer() do { PORTA.PIN7CTRL = (PORTA.PIN7CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT1_F_EnableInterruptForLowLevelSensing() do { PORTA.PIN7CTRL = (PORTA.PIN7CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PA7_SetInterruptHandler OCT1_F_SetInterruptHandler

//get/set OCT1_Gb aliases
#define OCT1_Gb_SetHigh() do { PORTB_OUTSET = 0x1; } while(0)
#define OCT1_Gb_SetLow() do { PORTB_OUTCLR = 0x1; } while(0)
#define OCT1_Gb_Toggle() do { PORTB_OUTTGL = 0x1; } while(0)
#define OCT1_Gb_GetValue() (VPORTB.IN & (0x1 << 0))
#define OCT1_Gb_SetDigitalInput() do { PORTB_DIRCLR = 0x1; } while(0)
#define OCT1_Gb_SetDigitalOutput() do { PORTB_DIRSET = 0x1; } while(0)
#define OCT1_Gb_SetPullUp() do { PORTB_PIN0CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT1_Gb_ResetPullUp() do { PORTB_PIN0CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT1_Gb_SetInverted() do { PORTB_PIN0CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT1_Gb_ResetInverted() do { PORTB_PIN0CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT1_Gb_DisableInterruptOnChange() do { PORTB.PIN0CTRL = (PORTB.PIN0CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT1_Gb_EnableInterruptForBothEdges() do { PORTB.PIN0CTRL = (PORTB.PIN0CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT1_Gb_EnableInterruptForRisingEdge() do { PORTB.PIN0CTRL = (PORTB.PIN0CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT1_Gb_EnableInterruptForFallingEdge() do { PORTB.PIN0CTRL = (PORTB.PIN0CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT1_Gb_DisableDigitalInputBuffer() do { PORTB.PIN0CTRL = (PORTB.PIN0CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT1_Gb_EnableInterruptForLowLevelSensing() do { PORTB.PIN0CTRL = (PORTB.PIN0CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PB0_SetInterruptHandler OCT1_Gb_SetInterruptHandler

//get/set OCT1_G aliases
#define OCT1_G_SetHigh() do { PORTB_OUTSET = 0x2; } while(0)
#define OCT1_G_SetLow() do { PORTB_OUTCLR = 0x2; } while(0)
#define OCT1_G_Toggle() do { PORTB_OUTTGL = 0x2; } while(0)
#define OCT1_G_GetValue() (VPORTB.IN & (0x1 << 1))
#define OCT1_G_SetDigitalInput() do { PORTB_DIRCLR = 0x2; } while(0)
#define OCT1_G_SetDigitalOutput() do { PORTB_DIRSET = 0x2; } while(0)
#define OCT1_G_SetPullUp() do { PORTB_PIN1CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT1_G_ResetPullUp() do { PORTB_PIN1CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT1_G_SetInverted() do { PORTB_PIN1CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT1_G_ResetInverted() do { PORTB_PIN1CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT1_G_DisableInterruptOnChange() do { PORTB.PIN1CTRL = (PORTB.PIN1CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT1_G_EnableInterruptForBothEdges() do { PORTB.PIN1CTRL = (PORTB.PIN1CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT1_G_EnableInterruptForRisingEdge() do { PORTB.PIN1CTRL = (PORTB.PIN1CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT1_G_EnableInterruptForFallingEdge() do { PORTB.PIN1CTRL = (PORTB.PIN1CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT1_G_DisableDigitalInputBuffer() do { PORTB.PIN1CTRL = (PORTB.PIN1CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT1_G_EnableInterruptForLowLevelSensing() do { PORTB.PIN1CTRL = (PORTB.PIN1CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PB1_SetInterruptHandler OCT1_G_SetInterruptHandler

//get/set OCT1_Ab aliases
#define OCT1_Ab_SetHigh() do { PORTB_OUTSET = 0x4; } while(0)
#define OCT1_Ab_SetLow() do { PORTB_OUTCLR = 0x4; } while(0)
#define OCT1_Ab_Toggle() do { PORTB_OUTTGL = 0x4; } while(0)
#define OCT1_Ab_GetValue() (VPORTB.IN & (0x1 << 2))
#define OCT1_Ab_SetDigitalInput() do { PORTB_DIRCLR = 0x4; } while(0)
#define OCT1_Ab_SetDigitalOutput() do { PORTB_DIRSET = 0x4; } while(0)
#define OCT1_Ab_SetPullUp() do { PORTB_PIN2CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT1_Ab_ResetPullUp() do { PORTB_PIN2CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT1_Ab_SetInverted() do { PORTB_PIN2CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT1_Ab_ResetInverted() do { PORTB_PIN2CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT1_Ab_DisableInterruptOnChange() do { PORTB.PIN2CTRL = (PORTB.PIN2CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT1_Ab_EnableInterruptForBothEdges() do { PORTB.PIN2CTRL = (PORTB.PIN2CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT1_Ab_EnableInterruptForRisingEdge() do { PORTB.PIN2CTRL = (PORTB.PIN2CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT1_Ab_EnableInterruptForFallingEdge() do { PORTB.PIN2CTRL = (PORTB.PIN2CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT1_Ab_DisableDigitalInputBuffer() do { PORTB.PIN2CTRL = (PORTB.PIN2CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT1_Ab_EnableInterruptForLowLevelSensing() do { PORTB.PIN2CTRL = (PORTB.PIN2CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PB2_SetInterruptHandler OCT1_Ab_SetInterruptHandler

//get/set OCT1_A aliases
#define OCT1_A_SetHigh() do { PORTB_OUTSET = 0x8; } while(0)
#define OCT1_A_SetLow() do { PORTB_OUTCLR = 0x8; } while(0)
#define OCT1_A_Toggle() do { PORTB_OUTTGL = 0x8; } while(0)
#define OCT1_A_GetValue() (VPORTB.IN & (0x1 << 3))
#define OCT1_A_SetDigitalInput() do { PORTB_DIRCLR = 0x8; } while(0)
#define OCT1_A_SetDigitalOutput() do { PORTB_DIRSET = 0x8; } while(0)
#define OCT1_A_SetPullUp() do { PORTB_PIN3CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT1_A_ResetPullUp() do { PORTB_PIN3CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT1_A_SetInverted() do { PORTB_PIN3CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT1_A_ResetInverted() do { PORTB_PIN3CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT1_A_DisableInterruptOnChange() do { PORTB.PIN3CTRL = (PORTB.PIN3CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT1_A_EnableInterruptForBothEdges() do { PORTB.PIN3CTRL = (PORTB.PIN3CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT1_A_EnableInterruptForRisingEdge() do { PORTB.PIN3CTRL = (PORTB.PIN3CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT1_A_EnableInterruptForFallingEdge() do { PORTB.PIN3CTRL = (PORTB.PIN3CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT1_A_DisableDigitalInputBuffer() do { PORTB.PIN3CTRL = (PORTB.PIN3CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT1_A_EnableInterruptForLowLevelSensing() do { PORTB.PIN3CTRL = (PORTB.PIN3CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PB3_SetInterruptHandler OCT1_A_SetInterruptHandler

//get/set OCT1_Bb aliases
#define OCT1_Bb_SetHigh() do { PORTB_OUTSET = 0x10; } while(0)
#define OCT1_Bb_SetLow() do { PORTB_OUTCLR = 0x10; } while(0)
#define OCT1_Bb_Toggle() do { PORTB_OUTTGL = 0x10; } while(0)
#define OCT1_Bb_GetValue() (VPORTB.IN & (0x1 << 4))
#define OCT1_Bb_SetDigitalInput() do { PORTB_DIRCLR = 0x10; } while(0)
#define OCT1_Bb_SetDigitalOutput() do { PORTB_DIRSET = 0x10; } while(0)
#define OCT1_Bb_SetPullUp() do { PORTB_PIN4CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT1_Bb_ResetPullUp() do { PORTB_PIN4CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT1_Bb_SetInverted() do { PORTB_PIN4CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT1_Bb_ResetInverted() do { PORTB_PIN4CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT1_Bb_DisableInterruptOnChange() do { PORTB.PIN4CTRL = (PORTB.PIN4CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT1_Bb_EnableInterruptForBothEdges() do { PORTB.PIN4CTRL = (PORTB.PIN4CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT1_Bb_EnableInterruptForRisingEdge() do { PORTB.PIN4CTRL = (PORTB.PIN4CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT1_Bb_EnableInterruptForFallingEdge() do { PORTB.PIN4CTRL = (PORTB.PIN4CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT1_Bb_DisableDigitalInputBuffer() do { PORTB.PIN4CTRL = (PORTB.PIN4CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT1_Bb_EnableInterruptForLowLevelSensing() do { PORTB.PIN4CTRL = (PORTB.PIN4CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PB4_SetInterruptHandler OCT1_Bb_SetInterruptHandler

//get/set OCT1_B aliases
#define OCT1_B_SetHigh() do { PORTB_OUTSET = 0x20; } while(0)
#define OCT1_B_SetLow() do { PORTB_OUTCLR = 0x20; } while(0)
#define OCT1_B_Toggle() do { PORTB_OUTTGL = 0x20; } while(0)
#define OCT1_B_GetValue() (VPORTB.IN & (0x1 << 5))
#define OCT1_B_SetDigitalInput() do { PORTB_DIRCLR = 0x20; } while(0)
#define OCT1_B_SetDigitalOutput() do { PORTB_DIRSET = 0x20; } while(0)
#define OCT1_B_SetPullUp() do { PORTB_PIN5CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT1_B_ResetPullUp() do { PORTB_PIN5CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT1_B_SetInverted() do { PORTB_PIN5CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT1_B_ResetInverted() do { PORTB_PIN5CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT1_B_DisableInterruptOnChange() do { PORTB.PIN5CTRL = (PORTB.PIN5CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT1_B_EnableInterruptForBothEdges() do { PORTB.PIN5CTRL = (PORTB.PIN5CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT1_B_EnableInterruptForRisingEdge() do { PORTB.PIN5CTRL = (PORTB.PIN5CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT1_B_EnableInterruptForFallingEdge() do { PORTB.PIN5CTRL = (PORTB.PIN5CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT1_B_DisableDigitalInputBuffer() do { PORTB.PIN5CTRL = (PORTB.PIN5CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT1_B_EnableInterruptForLowLevelSensing() do { PORTB.PIN5CTRL = (PORTB.PIN5CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PB5_SetInterruptHandler OCT1_B_SetInterruptHandler

//get/set OCT2_C aliases
#define OCT2_C_SetHigh() do { PORTC_OUTSET = 0x1; } while(0)
#define OCT2_C_SetLow() do { PORTC_OUTCLR = 0x1; } while(0)
#define OCT2_C_Toggle() do { PORTC_OUTTGL = 0x1; } while(0)
#define OCT2_C_GetValue() (VPORTC.IN & (0x1 << 0))
#define OCT2_C_SetDigitalInput() do { PORTC_DIRCLR = 0x1; } while(0)
#define OCT2_C_SetDigitalOutput() do { PORTC_DIRSET = 0x1; } while(0)
#define OCT2_C_SetPullUp() do { PORTC_PIN0CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT2_C_ResetPullUp() do { PORTC_PIN0CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT2_C_SetInverted() do { PORTC_PIN0CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT2_C_ResetInverted() do { PORTC_PIN0CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT2_C_DisableInterruptOnChange() do { PORTC.PIN0CTRL = (PORTC.PIN0CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT2_C_EnableInterruptForBothEdges() do { PORTC.PIN0CTRL = (PORTC.PIN0CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT2_C_EnableInterruptForRisingEdge() do { PORTC.PIN0CTRL = (PORTC.PIN0CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT2_C_EnableInterruptForFallingEdge() do { PORTC.PIN0CTRL = (PORTC.PIN0CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT2_C_DisableDigitalInputBuffer() do { PORTC.PIN0CTRL = (PORTC.PIN0CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT2_C_EnableInterruptForLowLevelSensing() do { PORTC.PIN0CTRL = (PORTC.PIN0CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PC0_SetInterruptHandler OCT2_C_SetInterruptHandler

//get/set OCT2_Db aliases
#define OCT2_Db_SetHigh() do { PORTC_OUTSET = 0x2; } while(0)
#define OCT2_Db_SetLow() do { PORTC_OUTCLR = 0x2; } while(0)
#define OCT2_Db_Toggle() do { PORTC_OUTTGL = 0x2; } while(0)
#define OCT2_Db_GetValue() (VPORTC.IN & (0x1 << 1))
#define OCT2_Db_SetDigitalInput() do { PORTC_DIRCLR = 0x2; } while(0)
#define OCT2_Db_SetDigitalOutput() do { PORTC_DIRSET = 0x2; } while(0)
#define OCT2_Db_SetPullUp() do { PORTC_PIN1CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT2_Db_ResetPullUp() do { PORTC_PIN1CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT2_Db_SetInverted() do { PORTC_PIN1CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT2_Db_ResetInverted() do { PORTC_PIN1CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT2_Db_DisableInterruptOnChange() do { PORTC.PIN1CTRL = (PORTC.PIN1CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT2_Db_EnableInterruptForBothEdges() do { PORTC.PIN1CTRL = (PORTC.PIN1CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT2_Db_EnableInterruptForRisingEdge() do { PORTC.PIN1CTRL = (PORTC.PIN1CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT2_Db_EnableInterruptForFallingEdge() do { PORTC.PIN1CTRL = (PORTC.PIN1CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT2_Db_DisableDigitalInputBuffer() do { PORTC.PIN1CTRL = (PORTC.PIN1CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT2_Db_EnableInterruptForLowLevelSensing() do { PORTC.PIN1CTRL = (PORTC.PIN1CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PC1_SetInterruptHandler OCT2_Db_SetInterruptHandler

//get/set OCT2_D aliases
#define OCT2_D_SetHigh() do { PORTC_OUTSET = 0x4; } while(0)
#define OCT2_D_SetLow() do { PORTC_OUTCLR = 0x4; } while(0)
#define OCT2_D_Toggle() do { PORTC_OUTTGL = 0x4; } while(0)
#define OCT2_D_GetValue() (VPORTC.IN & (0x1 << 2))
#define OCT2_D_SetDigitalInput() do { PORTC_DIRCLR = 0x4; } while(0)
#define OCT2_D_SetDigitalOutput() do { PORTC_DIRSET = 0x4; } while(0)
#define OCT2_D_SetPullUp() do { PORTC_PIN2CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT2_D_ResetPullUp() do { PORTC_PIN2CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT2_D_SetInverted() do { PORTC_PIN2CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT2_D_ResetInverted() do { PORTC_PIN2CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT2_D_DisableInterruptOnChange() do { PORTC.PIN2CTRL = (PORTC.PIN2CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT2_D_EnableInterruptForBothEdges() do { PORTC.PIN2CTRL = (PORTC.PIN2CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT2_D_EnableInterruptForRisingEdge() do { PORTC.PIN2CTRL = (PORTC.PIN2CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT2_D_EnableInterruptForFallingEdge() do { PORTC.PIN2CTRL = (PORTC.PIN2CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT2_D_DisableDigitalInputBuffer() do { PORTC.PIN2CTRL = (PORTC.PIN2CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT2_D_EnableInterruptForLowLevelSensing() do { PORTC.PIN2CTRL = (PORTC.PIN2CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PC2_SetInterruptHandler OCT2_D_SetInterruptHandler

//get/set OCT2_Eb aliases
#define OCT2_Eb_SetHigh() do { PORTC_OUTSET = 0x8; } while(0)
#define OCT2_Eb_SetLow() do { PORTC_OUTCLR = 0x8; } while(0)
#define OCT2_Eb_Toggle() do { PORTC_OUTTGL = 0x8; } while(0)
#define OCT2_Eb_GetValue() (VPORTC.IN & (0x1 << 3))
#define OCT2_Eb_SetDigitalInput() do { PORTC_DIRCLR = 0x8; } while(0)
#define OCT2_Eb_SetDigitalOutput() do { PORTC_DIRSET = 0x8; } while(0)
#define OCT2_Eb_SetPullUp() do { PORTC_PIN3CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT2_Eb_ResetPullUp() do { PORTC_PIN3CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT2_Eb_SetInverted() do { PORTC_PIN3CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT2_Eb_ResetInverted() do { PORTC_PIN3CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT2_Eb_DisableInterruptOnChange() do { PORTC.PIN3CTRL = (PORTC.PIN3CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT2_Eb_EnableInterruptForBothEdges() do { PORTC.PIN3CTRL = (PORTC.PIN3CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT2_Eb_EnableInterruptForRisingEdge() do { PORTC.PIN3CTRL = (PORTC.PIN3CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT2_Eb_EnableInterruptForFallingEdge() do { PORTC.PIN3CTRL = (PORTC.PIN3CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT2_Eb_DisableDigitalInputBuffer() do { PORTC.PIN3CTRL = (PORTC.PIN3CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT2_Eb_EnableInterruptForLowLevelSensing() do { PORTC.PIN3CTRL = (PORTC.PIN3CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PC3_SetInterruptHandler OCT2_Eb_SetInterruptHandler

//get/set OCT2_E aliases
#define OCT2_E_SetHigh() do { PORTC_OUTSET = 0x10; } while(0)
#define OCT2_E_SetLow() do { PORTC_OUTCLR = 0x10; } while(0)
#define OCT2_E_Toggle() do { PORTC_OUTTGL = 0x10; } while(0)
#define OCT2_E_GetValue() (VPORTC.IN & (0x1 << 4))
#define OCT2_E_SetDigitalInput() do { PORTC_DIRCLR = 0x10; } while(0)
#define OCT2_E_SetDigitalOutput() do { PORTC_DIRSET = 0x10; } while(0)
#define OCT2_E_SetPullUp() do { PORTC_PIN4CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT2_E_ResetPullUp() do { PORTC_PIN4CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT2_E_SetInverted() do { PORTC_PIN4CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT2_E_ResetInverted() do { PORTC_PIN4CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT2_E_DisableInterruptOnChange() do { PORTC.PIN4CTRL = (PORTC.PIN4CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT2_E_EnableInterruptForBothEdges() do { PORTC.PIN4CTRL = (PORTC.PIN4CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT2_E_EnableInterruptForRisingEdge() do { PORTC.PIN4CTRL = (PORTC.PIN4CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT2_E_EnableInterruptForFallingEdge() do { PORTC.PIN4CTRL = (PORTC.PIN4CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT2_E_DisableDigitalInputBuffer() do { PORTC.PIN4CTRL = (PORTC.PIN4CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT2_E_EnableInterruptForLowLevelSensing() do { PORTC.PIN4CTRL = (PORTC.PIN4CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PC4_SetInterruptHandler OCT2_E_SetInterruptHandler

//get/set OCT2_F aliases
#define OCT2_F_SetHigh() do { PORTC_OUTSET = 0x20; } while(0)
#define OCT2_F_SetLow() do { PORTC_OUTCLR = 0x20; } while(0)
#define OCT2_F_Toggle() do { PORTC_OUTTGL = 0x20; } while(0)
#define OCT2_F_GetValue() (VPORTC.IN & (0x1 << 5))
#define OCT2_F_SetDigitalInput() do { PORTC_DIRCLR = 0x20; } while(0)
#define OCT2_F_SetDigitalOutput() do { PORTC_DIRSET = 0x20; } while(0)
#define OCT2_F_SetPullUp() do { PORTC_PIN5CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT2_F_ResetPullUp() do { PORTC_PIN5CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT2_F_SetInverted() do { PORTC_PIN5CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT2_F_ResetInverted() do { PORTC_PIN5CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT2_F_DisableInterruptOnChange() do { PORTC.PIN5CTRL = (PORTC.PIN5CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT2_F_EnableInterruptForBothEdges() do { PORTC.PIN5CTRL = (PORTC.PIN5CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT2_F_EnableInterruptForRisingEdge() do { PORTC.PIN5CTRL = (PORTC.PIN5CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT2_F_EnableInterruptForFallingEdge() do { PORTC.PIN5CTRL = (PORTC.PIN5CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT2_F_DisableDigitalInputBuffer() do { PORTC.PIN5CTRL = (PORTC.PIN5CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT2_F_EnableInterruptForLowLevelSensing() do { PORTC.PIN5CTRL = (PORTC.PIN5CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PC5_SetInterruptHandler OCT2_F_SetInterruptHandler

//get/set OCT2_Gb aliases
#define OCT2_Gb_SetHigh() do { PORTC_OUTSET = 0x40; } while(0)
#define OCT2_Gb_SetLow() do { PORTC_OUTCLR = 0x40; } while(0)
#define OCT2_Gb_Toggle() do { PORTC_OUTTGL = 0x40; } while(0)
#define OCT2_Gb_GetValue() (VPORTC.IN & (0x1 << 6))
#define OCT2_Gb_SetDigitalInput() do { PORTC_DIRCLR = 0x40; } while(0)
#define OCT2_Gb_SetDigitalOutput() do { PORTC_DIRSET = 0x40; } while(0)
#define OCT2_Gb_SetPullUp() do { PORTC_PIN6CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT2_Gb_ResetPullUp() do { PORTC_PIN6CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT2_Gb_SetInverted() do { PORTC_PIN6CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT2_Gb_ResetInverted() do { PORTC_PIN6CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT2_Gb_DisableInterruptOnChange() do { PORTC.PIN6CTRL = (PORTC.PIN6CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT2_Gb_EnableInterruptForBothEdges() do { PORTC.PIN6CTRL = (PORTC.PIN6CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT2_Gb_EnableInterruptForRisingEdge() do { PORTC.PIN6CTRL = (PORTC.PIN6CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT2_Gb_EnableInterruptForFallingEdge() do { PORTC.PIN6CTRL = (PORTC.PIN6CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT2_Gb_DisableDigitalInputBuffer() do { PORTC.PIN6CTRL = (PORTC.PIN6CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT2_Gb_EnableInterruptForLowLevelSensing() do { PORTC.PIN6CTRL = (PORTC.PIN6CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PC6_SetInterruptHandler OCT2_Gb_SetInterruptHandler

//get/set OCT2_G aliases
#define OCT2_G_SetHigh() do { PORTC_OUTSET = 0x80; } while(0)
#define OCT2_G_SetLow() do { PORTC_OUTCLR = 0x80; } while(0)
#define OCT2_G_Toggle() do { PORTC_OUTTGL = 0x80; } while(0)
#define OCT2_G_GetValue() (VPORTC.IN & (0x1 << 7))
#define OCT2_G_SetDigitalInput() do { PORTC_DIRCLR = 0x80; } while(0)
#define OCT2_G_SetDigitalOutput() do { PORTC_DIRSET = 0x80; } while(0)
#define OCT2_G_SetPullUp() do { PORTC_PIN7CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT2_G_ResetPullUp() do { PORTC_PIN7CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT2_G_SetInverted() do { PORTC_PIN7CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT2_G_ResetInverted() do { PORTC_PIN7CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT2_G_DisableInterruptOnChange() do { PORTC.PIN7CTRL = (PORTC.PIN7CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT2_G_EnableInterruptForBothEdges() do { PORTC.PIN7CTRL = (PORTC.PIN7CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT2_G_EnableInterruptForRisingEdge() do { PORTC.PIN7CTRL = (PORTC.PIN7CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT2_G_EnableInterruptForFallingEdge() do { PORTC.PIN7CTRL = (PORTC.PIN7CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT2_G_DisableDigitalInputBuffer() do { PORTC.PIN7CTRL = (PORTC.PIN7CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT2_G_EnableInterruptForLowLevelSensing() do { PORTC.PIN7CTRL = (PORTC.PIN7CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PC7_SetInterruptHandler OCT2_G_SetInterruptHandler

//get/set OCT2_Ab aliases
#define OCT2_Ab_SetHigh() do { PORTD_OUTSET = 0x1; } while(0)
#define OCT2_Ab_SetLow() do { PORTD_OUTCLR = 0x1; } while(0)
#define OCT2_Ab_Toggle() do { PORTD_OUTTGL = 0x1; } while(0)
#define OCT2_Ab_GetValue() (VPORTD.IN & (0x1 << 0))
#define OCT2_Ab_SetDigitalInput() do { PORTD_DIRCLR = 0x1; } while(0)
#define OCT2_Ab_SetDigitalOutput() do { PORTD_DIRSET = 0x1; } while(0)
#define OCT2_Ab_SetPullUp() do { PORTD_PIN0CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT2_Ab_ResetPullUp() do { PORTD_PIN0CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT2_Ab_SetInverted() do { PORTD_PIN0CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT2_Ab_ResetInverted() do { PORTD_PIN0CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT2_Ab_DisableInterruptOnChange() do { PORTD.PIN0CTRL = (PORTD.PIN0CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT2_Ab_EnableInterruptForBothEdges() do { PORTD.PIN0CTRL = (PORTD.PIN0CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT2_Ab_EnableInterruptForRisingEdge() do { PORTD.PIN0CTRL = (PORTD.PIN0CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT2_Ab_EnableInterruptForFallingEdge() do { PORTD.PIN0CTRL = (PORTD.PIN0CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT2_Ab_DisableDigitalInputBuffer() do { PORTD.PIN0CTRL = (PORTD.PIN0CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT2_Ab_EnableInterruptForLowLevelSensing() do { PORTD.PIN0CTRL = (PORTD.PIN0CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PD0_SetInterruptHandler OCT2_Ab_SetInterruptHandler

//get/set OCT2_A aliases
#define OCT2_A_SetHigh() do { PORTD_OUTSET = 0x2; } while(0)
#define OCT2_A_SetLow() do { PORTD_OUTCLR = 0x2; } while(0)
#define OCT2_A_Toggle() do { PORTD_OUTTGL = 0x2; } while(0)
#define OCT2_A_GetValue() (VPORTD.IN & (0x1 << 1))
#define OCT2_A_SetDigitalInput() do { PORTD_DIRCLR = 0x2; } while(0)
#define OCT2_A_SetDigitalOutput() do { PORTD_DIRSET = 0x2; } while(0)
#define OCT2_A_SetPullUp() do { PORTD_PIN1CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT2_A_ResetPullUp() do { PORTD_PIN1CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT2_A_SetInverted() do { PORTD_PIN1CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT2_A_ResetInverted() do { PORTD_PIN1CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT2_A_DisableInterruptOnChange() do { PORTD.PIN1CTRL = (PORTD.PIN1CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT2_A_EnableInterruptForBothEdges() do { PORTD.PIN1CTRL = (PORTD.PIN1CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT2_A_EnableInterruptForRisingEdge() do { PORTD.PIN1CTRL = (PORTD.PIN1CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT2_A_EnableInterruptForFallingEdge() do { PORTD.PIN1CTRL = (PORTD.PIN1CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT2_A_DisableDigitalInputBuffer() do { PORTD.PIN1CTRL = (PORTD.PIN1CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT2_A_EnableInterruptForLowLevelSensing() do { PORTD.PIN1CTRL = (PORTD.PIN1CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PD1_SetInterruptHandler OCT2_A_SetInterruptHandler

//get/set OCT2_Bb aliases
#define OCT2_Bb_SetHigh() do { PORTD_OUTSET = 0x4; } while(0)
#define OCT2_Bb_SetLow() do { PORTD_OUTCLR = 0x4; } while(0)
#define OCT2_Bb_Toggle() do { PORTD_OUTTGL = 0x4; } while(0)
#define OCT2_Bb_GetValue() (VPORTD.IN & (0x1 << 2))
#define OCT2_Bb_SetDigitalInput() do { PORTD_DIRCLR = 0x4; } while(0)
#define OCT2_Bb_SetDigitalOutput() do { PORTD_DIRSET = 0x4; } while(0)
#define OCT2_Bb_SetPullUp() do { PORTD_PIN2CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT2_Bb_ResetPullUp() do { PORTD_PIN2CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT2_Bb_SetInverted() do { PORTD_PIN2CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT2_Bb_ResetInverted() do { PORTD_PIN2CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT2_Bb_DisableInterruptOnChange() do { PORTD.PIN2CTRL = (PORTD.PIN2CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT2_Bb_EnableInterruptForBothEdges() do { PORTD.PIN2CTRL = (PORTD.PIN2CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT2_Bb_EnableInterruptForRisingEdge() do { PORTD.PIN2CTRL = (PORTD.PIN2CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT2_Bb_EnableInterruptForFallingEdge() do { PORTD.PIN2CTRL = (PORTD.PIN2CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT2_Bb_DisableDigitalInputBuffer() do { PORTD.PIN2CTRL = (PORTD.PIN2CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT2_Bb_EnableInterruptForLowLevelSensing() do { PORTD.PIN2CTRL = (PORTD.PIN2CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PD2_SetInterruptHandler OCT2_Bb_SetInterruptHandler

//get/set OCT2_B aliases
#define OCT2_B_SetHigh() do { PORTD_OUTSET = 0x8; } while(0)
#define OCT2_B_SetLow() do { PORTD_OUTCLR = 0x8; } while(0)
#define OCT2_B_Toggle() do { PORTD_OUTTGL = 0x8; } while(0)
#define OCT2_B_GetValue() (VPORTD.IN & (0x1 << 3))
#define OCT2_B_SetDigitalInput() do { PORTD_DIRCLR = 0x8; } while(0)
#define OCT2_B_SetDigitalOutput() do { PORTD_DIRSET = 0x8; } while(0)
#define OCT2_B_SetPullUp() do { PORTD_PIN3CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT2_B_ResetPullUp() do { PORTD_PIN3CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT2_B_SetInverted() do { PORTD_PIN3CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT2_B_ResetInverted() do { PORTD_PIN3CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT2_B_DisableInterruptOnChange() do { PORTD.PIN3CTRL = (PORTD.PIN3CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT2_B_EnableInterruptForBothEdges() do { PORTD.PIN3CTRL = (PORTD.PIN3CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT2_B_EnableInterruptForRisingEdge() do { PORTD.PIN3CTRL = (PORTD.PIN3CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT2_B_EnableInterruptForFallingEdge() do { PORTD.PIN3CTRL = (PORTD.PIN3CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT2_B_DisableDigitalInputBuffer() do { PORTD.PIN3CTRL = (PORTD.PIN3CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT2_B_EnableInterruptForLowLevelSensing() do { PORTD.PIN3CTRL = (PORTD.PIN3CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PD3_SetInterruptHandler OCT2_B_SetInterruptHandler

//get/set OCT3_C aliases
#define OCT3_C_SetHigh() do { PORTD_OUTSET = 0x10; } while(0)
#define OCT3_C_SetLow() do { PORTD_OUTCLR = 0x10; } while(0)
#define OCT3_C_Toggle() do { PORTD_OUTTGL = 0x10; } while(0)
#define OCT3_C_GetValue() (VPORTD.IN & (0x1 << 4))
#define OCT3_C_SetDigitalInput() do { PORTD_DIRCLR = 0x10; } while(0)
#define OCT3_C_SetDigitalOutput() do { PORTD_DIRSET = 0x10; } while(0)
#define OCT3_C_SetPullUp() do { PORTD_PIN4CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define OCT3_C_ResetPullUp() do { PORTD_PIN4CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define OCT3_C_SetInverted() do { PORTD_PIN4CTRL  |= PORT_INVEN_bm; } while(0)
#define OCT3_C_ResetInverted() do { PORTD_PIN4CTRL  &= ~PORT_INVEN_bm; } while(0)
#define OCT3_C_DisableInterruptOnChange() do { PORTD.PIN4CTRL = (PORTD.PIN4CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define OCT3_C_EnableInterruptForBothEdges() do { PORTD.PIN4CTRL = (PORTD.PIN4CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define OCT3_C_EnableInterruptForRisingEdge() do { PORTD.PIN4CTRL = (PORTD.PIN4CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define OCT3_C_EnableInterruptForFallingEdge() do { PORTD.PIN4CTRL = (PORTD.PIN4CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define OCT3_C_DisableDigitalInputBuffer() do { PORTD.PIN4CTRL = (PORTD.PIN4CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define OCT3_C_EnableInterruptForLowLevelSensing() do { PORTD.PIN4CTRL = (PORTD.PIN4CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PD4_SetInterruptHandler OCT3_C_SetInterruptHandler

//get/set midi aliases
#define midi_SetHigh() do { PORTD_OUTSET = 0x20; } while(0)
#define midi_SetLow() do { PORTD_OUTCLR = 0x20; } while(0)
#define midi_Toggle() do { PORTD_OUTTGL = 0x20; } while(0)
#define midi_GetValue() (VPORTD.IN & (0x1 << 5))
#define midi_SetDigitalInput() do { PORTD_DIRCLR = 0x20; } while(0)
#define midi_SetDigitalOutput() do { PORTD_DIRSET = 0x20; } while(0)
#define midi_SetPullUp() do { PORTD_PIN5CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define midi_ResetPullUp() do { PORTD_PIN5CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define midi_SetInverted() do { PORTD_PIN5CTRL  |= PORT_INVEN_bm; } while(0)
#define midi_ResetInverted() do { PORTD_PIN5CTRL  &= ~PORT_INVEN_bm; } while(0)
#define midi_DisableInterruptOnChange() do { PORTD.PIN5CTRL = (PORTD.PIN5CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define midi_EnableInterruptForBothEdges() do { PORTD.PIN5CTRL = (PORTD.PIN5CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define midi_EnableInterruptForRisingEdge() do { PORTD.PIN5CTRL = (PORTD.PIN5CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define midi_EnableInterruptForFallingEdge() do { PORTD.PIN5CTRL = (PORTD.PIN5CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define midi_DisableDigitalInputBuffer() do { PORTD.PIN5CTRL = (PORTD.PIN5CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define midi_EnableInterruptForLowLevelSensing() do { PORTD.PIN5CTRL = (PORTD.PIN5CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PD5_SetInterruptHandler midi_SetInterruptHandler

//get/set gate aliases
#define gate_SetHigh() do { PORTD_OUTSET = 0x80; } while(0)
#define gate_SetLow() do { PORTD_OUTCLR = 0x80; } while(0)
#define gate_Toggle() do { PORTD_OUTTGL = 0x80; } while(0)
#define gate_GetValue() (VPORTD.IN & (0x1 << 7))
#define gate_SetDigitalInput() do { PORTD_DIRCLR = 0x80; } while(0)
#define gate_SetDigitalOutput() do { PORTD_DIRSET = 0x80; } while(0)
#define gate_SetPullUp() do { PORTD_PIN7CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define gate_ResetPullUp() do { PORTD_PIN7CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define gate_SetInverted() do { PORTD_PIN7CTRL  |= PORT_INVEN_bm; } while(0)
#define gate_ResetInverted() do { PORTD_PIN7CTRL  &= ~PORT_INVEN_bm; } while(0)
#define gate_DisableInterruptOnChange() do { PORTD.PIN7CTRL = (PORTD.PIN7CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define gate_EnableInterruptForBothEdges() do { PORTD.PIN7CTRL = (PORTD.PIN7CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define gate_EnableInterruptForRisingEdge() do { PORTD.PIN7CTRL = (PORTD.PIN7CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define gate_EnableInterruptForFallingEdge() do { PORTD.PIN7CTRL = (PORTD.PIN7CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define gate_DisableDigitalInputBuffer() do { PORTD.PIN7CTRL = (PORTD.PIN7CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define gate_EnableInterruptForLowLevelSensing() do { PORTD.PIN7CTRL = (PORTD.PIN7CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PD7_SetInterruptHandler gate_SetInterruptHandler

//get/set schakelaar aliases
#define schakelaar_SetHigh() do { PORTE_OUTSET = 0x8; } while(0)
#define schakelaar_SetLow() do { PORTE_OUTCLR = 0x8; } while(0)
#define schakelaar_Toggle() do { PORTE_OUTTGL = 0x8; } while(0)
#define schakelaar_GetValue() (VPORTE.IN & (0x1 << 3))
#define schakelaar_SetDigitalInput() do { PORTE_DIRCLR = 0x8; } while(0)
#define schakelaar_SetDigitalOutput() do { PORTE_DIRSET = 0x8; } while(0)
#define schakelaar_SetPullUp() do { PORTE_PIN3CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define schakelaar_ResetPullUp() do { PORTE_PIN3CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define schakelaar_SetInverted() do { PORTE_PIN3CTRL  |= PORT_INVEN_bm; } while(0)
#define schakelaar_ResetInverted() do { PORTE_PIN3CTRL  &= ~PORT_INVEN_bm; } while(0)
#define schakelaar_DisableInterruptOnChange() do { PORTE.PIN3CTRL = (PORTE.PIN3CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define schakelaar_EnableInterruptForBothEdges() do { PORTE.PIN3CTRL = (PORTE.PIN3CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define schakelaar_EnableInterruptForRisingEdge() do { PORTE.PIN3CTRL = (PORTE.PIN3CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define schakelaar_EnableInterruptForFallingEdge() do { PORTE.PIN3CTRL = (PORTE.PIN3CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define schakelaar_DisableDigitalInputBuffer() do { PORTE.PIN3CTRL = (PORTE.PIN3CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define schakelaar_EnableInterruptForLowLevelSensing() do { PORTE.PIN3CTRL = (PORTE.PIN3CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PE3_SetInterruptHandler schakelaar_SetInterruptHandler

//get/set IO_PF3 aliases
#define IO_PF3_SetHigh() do { PORTF_OUTSET = 0x8; } while(0)
#define IO_PF3_SetLow() do { PORTF_OUTCLR = 0x8; } while(0)
#define IO_PF3_Toggle() do { PORTF_OUTTGL = 0x8; } while(0)
#define IO_PF3_GetValue() (VPORTF.IN & (0x1 << 3))
#define IO_PF3_SetDigitalInput() do { PORTF_DIRCLR = 0x8; } while(0)
#define IO_PF3_SetDigitalOutput() do { PORTF_DIRSET = 0x8; } while(0)
#define IO_PF3_SetPullUp() do { PORTF_PIN3CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define IO_PF3_ResetPullUp() do { PORTF_PIN3CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define IO_PF3_SetInverted() do { PORTF_PIN3CTRL  |= PORT_INVEN_bm; } while(0)
#define IO_PF3_ResetInverted() do { PORTF_PIN3CTRL  &= ~PORT_INVEN_bm; } while(0)
#define IO_PF3_DisableInterruptOnChange() do { PORTF.PIN3CTRL = (PORTF.PIN3CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define IO_PF3_EnableInterruptForBothEdges() do { PORTF.PIN3CTRL = (PORTF.PIN3CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define IO_PF3_EnableInterruptForRisingEdge() do { PORTF.PIN3CTRL = (PORTF.PIN3CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define IO_PF3_EnableInterruptForFallingEdge() do { PORTF.PIN3CTRL = (PORTF.PIN3CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define IO_PF3_DisableDigitalInputBuffer() do { PORTF.PIN3CTRL = (PORTF.PIN3CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define IO_PF3_EnableInterruptForLowLevelSensing() do { PORTF.PIN3CTRL = (PORTF.PIN3CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PF3_SetInterruptHandler IO_PF3_SetInterruptHandler

//get/set IO_PF5 aliases
#define IO_PF5_SetHigh() do { PORTF_OUTSET = 0x20; } while(0)
#define IO_PF5_SetLow() do { PORTF_OUTCLR = 0x20; } while(0)
#define IO_PF5_Toggle() do { PORTF_OUTTGL = 0x20; } while(0)
#define IO_PF5_GetValue() (VPORTF.IN & (0x1 << 5))
#define IO_PF5_SetDigitalInput() do { PORTF_DIRCLR = 0x20; } while(0)
#define IO_PF5_SetDigitalOutput() do { PORTF_DIRSET = 0x20; } while(0)
#define IO_PF5_SetPullUp() do { PORTF_PIN5CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define IO_PF5_ResetPullUp() do { PORTF_PIN5CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define IO_PF5_SetInverted() do { PORTF_PIN5CTRL  |= PORT_INVEN_bm; } while(0)
#define IO_PF5_ResetInverted() do { PORTF_PIN5CTRL  &= ~PORT_INVEN_bm; } while(0)
#define IO_PF5_DisableInterruptOnChange() do { PORTF.PIN5CTRL = (PORTF.PIN5CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define IO_PF5_EnableInterruptForBothEdges() do { PORTF.PIN5CTRL = (PORTF.PIN5CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define IO_PF5_EnableInterruptForRisingEdge() do { PORTF.PIN5CTRL = (PORTF.PIN5CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define IO_PF5_EnableInterruptForFallingEdge() do { PORTF.PIN5CTRL = (PORTF.PIN5CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define IO_PF5_DisableDigitalInputBuffer() do { PORTF.PIN5CTRL = (PORTF.PIN5CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define IO_PF5_EnableInterruptForLowLevelSensing() do { PORTF.PIN5CTRL = (PORTF.PIN5CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PF5_SetInterruptHandler IO_PF5_SetInterruptHandler

//get/set IO_PF6 aliases
#define IO_PF6_SetHigh() do { PORTF_OUTSET = 0x40; } while(0)
#define IO_PF6_SetLow() do { PORTF_OUTCLR = 0x40; } while(0)
#define IO_PF6_Toggle() do { PORTF_OUTTGL = 0x40; } while(0)
#define IO_PF6_GetValue() (VPORTF.IN & (0x1 << 6))
#define IO_PF6_SetDigitalInput() do { PORTF_DIRCLR = 0x40; } while(0)
#define IO_PF6_SetDigitalOutput() do { PORTF_DIRSET = 0x40; } while(0)
#define IO_PF6_SetPullUp() do { PORTF_PIN6CTRL  |= PORT_PULLUPEN_bm; } while(0)
#define IO_PF6_ResetPullUp() do { PORTF_PIN6CTRL  &= ~PORT_PULLUPEN_bm; } while(0)
#define IO_PF6_SetInverted() do { PORTF_PIN6CTRL  |= PORT_INVEN_bm; } while(0)
#define IO_PF6_ResetInverted() do { PORTF_PIN6CTRL  &= ~PORT_INVEN_bm; } while(0)
#define IO_PF6_DisableInterruptOnChange() do { PORTF.PIN6CTRL = (PORTF.PIN6CTRL & ~PORT_ISC_gm) | 0x0 ; } while(0)
#define IO_PF6_EnableInterruptForBothEdges() do { PORTF.PIN6CTRL = (PORTF.PIN6CTRL & ~PORT_ISC_gm) | 0x1 ; } while(0)
#define IO_PF6_EnableInterruptForRisingEdge() do { PORTF.PIN6CTRL = (PORTF.PIN6CTRL & ~PORT_ISC_gm) | 0x2 ; } while(0)
#define IO_PF6_EnableInterruptForFallingEdge() do { PORTF.PIN6CTRL = (PORTF.PIN6CTRL & ~PORT_ISC_gm) | 0x3 ; } while(0)
#define IO_PF6_DisableDigitalInputBuffer() do { PORTF.PIN6CTRL = (PORTF.PIN6CTRL & ~PORT_ISC_gm) | 0x4 ; } while(0)
#define IO_PF6_EnableInterruptForLowLevelSensing() do { PORTF.PIN6CTRL = (PORTF.PIN6CTRL & ~PORT_ISC_gm) | 0x5 ; } while(0)
#define PF6_SetInterruptHandler IO_PF6_SetInterruptHandler

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize();

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for DAC pin. 
 *        This is a predefined interrupt handler to be used together with the DAC_SetInterruptHandler() method.
 *        This handler is called every time the DAC ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void DAC_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for DAC pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for DAC at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void DAC_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT1_C pin. 
 *        This is a predefined interrupt handler to be used together with the OCT1_C_SetInterruptHandler() method.
 *        This handler is called every time the OCT1_C ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT1_C_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT1_C pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT1_C at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT1_C_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT1_Db pin. 
 *        This is a predefined interrupt handler to be used together with the OCT1_Db_SetInterruptHandler() method.
 *        This handler is called every time the OCT1_Db ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT1_Db_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT1_Db pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT1_Db at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT1_Db_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT1_D pin. 
 *        This is a predefined interrupt handler to be used together with the OCT1_D_SetInterruptHandler() method.
 *        This handler is called every time the OCT1_D ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT1_D_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT1_D pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT1_D at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT1_D_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT1_Eb pin. 
 *        This is a predefined interrupt handler to be used together with the OCT1_Eb_SetInterruptHandler() method.
 *        This handler is called every time the OCT1_Eb ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT1_Eb_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT1_Eb pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT1_Eb at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT1_Eb_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT1_E pin. 
 *        This is a predefined interrupt handler to be used together with the OCT1_E_SetInterruptHandler() method.
 *        This handler is called every time the OCT1_E ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT1_E_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT1_E pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT1_E at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT1_E_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT1_F pin. 
 *        This is a predefined interrupt handler to be used together with the OCT1_F_SetInterruptHandler() method.
 *        This handler is called every time the OCT1_F ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT1_F_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT1_F pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT1_F at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT1_F_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT1_Gb pin. 
 *        This is a predefined interrupt handler to be used together with the OCT1_Gb_SetInterruptHandler() method.
 *        This handler is called every time the OCT1_Gb ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT1_Gb_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT1_Gb pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT1_Gb at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT1_Gb_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT1_G pin. 
 *        This is a predefined interrupt handler to be used together with the OCT1_G_SetInterruptHandler() method.
 *        This handler is called every time the OCT1_G ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT1_G_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT1_G pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT1_G at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT1_G_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT1_Ab pin. 
 *        This is a predefined interrupt handler to be used together with the OCT1_Ab_SetInterruptHandler() method.
 *        This handler is called every time the OCT1_Ab ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT1_Ab_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT1_Ab pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT1_Ab at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT1_Ab_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT1_A pin. 
 *        This is a predefined interrupt handler to be used together with the OCT1_A_SetInterruptHandler() method.
 *        This handler is called every time the OCT1_A ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT1_A_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT1_A pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT1_A at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT1_A_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT1_Bb pin. 
 *        This is a predefined interrupt handler to be used together with the OCT1_Bb_SetInterruptHandler() method.
 *        This handler is called every time the OCT1_Bb ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT1_Bb_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT1_Bb pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT1_Bb at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT1_Bb_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT1_B pin. 
 *        This is a predefined interrupt handler to be used together with the OCT1_B_SetInterruptHandler() method.
 *        This handler is called every time the OCT1_B ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT1_B_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT1_B pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT1_B at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT1_B_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT2_C pin. 
 *        This is a predefined interrupt handler to be used together with the OCT2_C_SetInterruptHandler() method.
 *        This handler is called every time the OCT2_C ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT2_C_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT2_C pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT2_C at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT2_C_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT2_Db pin. 
 *        This is a predefined interrupt handler to be used together with the OCT2_Db_SetInterruptHandler() method.
 *        This handler is called every time the OCT2_Db ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT2_Db_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT2_Db pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT2_Db at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT2_Db_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT2_D pin. 
 *        This is a predefined interrupt handler to be used together with the OCT2_D_SetInterruptHandler() method.
 *        This handler is called every time the OCT2_D ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT2_D_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT2_D pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT2_D at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT2_D_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT2_Eb pin. 
 *        This is a predefined interrupt handler to be used together with the OCT2_Eb_SetInterruptHandler() method.
 *        This handler is called every time the OCT2_Eb ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT2_Eb_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT2_Eb pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT2_Eb at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT2_Eb_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT2_E pin. 
 *        This is a predefined interrupt handler to be used together with the OCT2_E_SetInterruptHandler() method.
 *        This handler is called every time the OCT2_E ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT2_E_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT2_E pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT2_E at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT2_E_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT2_F pin. 
 *        This is a predefined interrupt handler to be used together with the OCT2_F_SetInterruptHandler() method.
 *        This handler is called every time the OCT2_F ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT2_F_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT2_F pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT2_F at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT2_F_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT2_Gb pin. 
 *        This is a predefined interrupt handler to be used together with the OCT2_Gb_SetInterruptHandler() method.
 *        This handler is called every time the OCT2_Gb ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT2_Gb_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT2_Gb pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT2_Gb at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT2_Gb_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT2_G pin. 
 *        This is a predefined interrupt handler to be used together with the OCT2_G_SetInterruptHandler() method.
 *        This handler is called every time the OCT2_G ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT2_G_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT2_G pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT2_G at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT2_G_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT2_Ab pin. 
 *        This is a predefined interrupt handler to be used together with the OCT2_Ab_SetInterruptHandler() method.
 *        This handler is called every time the OCT2_Ab ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT2_Ab_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT2_Ab pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT2_Ab at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT2_Ab_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT2_A pin. 
 *        This is a predefined interrupt handler to be used together with the OCT2_A_SetInterruptHandler() method.
 *        This handler is called every time the OCT2_A ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT2_A_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT2_A pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT2_A at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT2_A_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT2_Bb pin. 
 *        This is a predefined interrupt handler to be used together with the OCT2_Bb_SetInterruptHandler() method.
 *        This handler is called every time the OCT2_Bb ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT2_Bb_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT2_Bb pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT2_Bb at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT2_Bb_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT2_B pin. 
 *        This is a predefined interrupt handler to be used together with the OCT2_B_SetInterruptHandler() method.
 *        This handler is called every time the OCT2_B ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT2_B_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT2_B pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT2_B at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT2_B_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for OCT3_C pin. 
 *        This is a predefined interrupt handler to be used together with the OCT3_C_SetInterruptHandler() method.
 *        This handler is called every time the OCT3_C ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void OCT3_C_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for OCT3_C pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for OCT3_C at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void OCT3_C_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for midi pin. 
 *        This is a predefined interrupt handler to be used together with the midi_SetInterruptHandler() method.
 *        This handler is called every time the midi ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void midi_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for midi pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for midi at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void midi_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for gate pin. 
 *        This is a predefined interrupt handler to be used together with the gate_SetInterruptHandler() method.
 *        This handler is called every time the gate ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void gate_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for gate pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for gate at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void gate_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for schakelaar pin. 
 *        This is a predefined interrupt handler to be used together with the schakelaar_SetInterruptHandler() method.
 *        This handler is called every time the schakelaar ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void schakelaar_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for schakelaar pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for schakelaar at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void schakelaar_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for IO_PF3 pin. 
 *        This is a predefined interrupt handler to be used together with the IO_PF3_SetInterruptHandler() method.
 *        This handler is called every time the IO_PF3 ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void IO_PF3_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for IO_PF3 pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for IO_PF3 at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void IO_PF3_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for IO_PF5 pin. 
 *        This is a predefined interrupt handler to be used together with the IO_PF5_SetInterruptHandler() method.
 *        This handler is called every time the IO_PF5 ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void IO_PF5_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for IO_PF5 pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for IO_PF5 at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void IO_PF5_SetInterruptHandler(void (* interruptHandler)(void)) ; 

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for IO_PF6 pin. 
 *        This is a predefined interrupt handler to be used together with the IO_PF6_SetInterruptHandler() method.
 *        This handler is called every time the IO_PF6 ISR is executed. 
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param none
 * @return none
 */
void IO_PF6_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for IO_PF6 pin input-sense-config functionality.
 *        Allows selecting an interrupt handler for IO_PF6 at application runtime
 * @pre PIN_MANAGER_Initialize() has been called at least once
 * @param InterruptHandler function pointer.
 * @return none
 */
void IO_PF6_SetInterruptHandler(void (* interruptHandler)(void)) ; 
#endif /* PINS_H_INCLUDED */
