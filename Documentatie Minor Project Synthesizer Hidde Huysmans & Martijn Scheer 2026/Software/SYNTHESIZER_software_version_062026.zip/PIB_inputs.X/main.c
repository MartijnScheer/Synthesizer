#include "mcc_generated_files/system/system.h"
#include <util/delay.h>

uint16_t DAC_value = 0;

void Analoge_Input(void);
void Digitale_Input(void);
void DAC_SetOutput(uint16_t value);
void gate_pulse(void);

int main(void) {
SYSTEM_Initialize();

if (schakelaar_GetValue()){ //Schakelaar_GetValue gaf altijd dezelfde waarde! Vandaar dat deze nu Hard op Analoge_Input(); gezet is.
    Analoge_Input();        //Als MIDI(digitale input) op de planning staat, moet eerst even gekeken worden naar deze functie weer-
}                           //-werkende krijgen op basis van de stand van de fysieke schakelaar op de Synthesizer input module.
else{                       //Dit probleem kan zowel software matig zijn (misschien heb ik iets gemist) of hardware matig (misschien kabel los)
    Analoge_Input();        //TIP: het heeft voor deze versie van de software wel gewerkt, stel het probleem is softwarematig dan moet je de 2024/2025-
}                           //-versie er even naast leggen. Maar ondertussen is er hardwarematig ook gepruts waardoor iets los kan zijn geraakt.
}

void DAC_SetOutput(uint16_t value) {
DAC0.DATA = value;

}

void gate_pulse(void) {
gate_SetLow();
_delay_ms(10);
gate_SetHigh();
}

typedef enum {
IDLE, BUTTON_1, BUTTON_2, BUTTON_3, BUTTON_4, BUTTON_5,
BUTTON_6, BUTTON_7, BUTTON_8, BUTTON_9, BUTTON_10,
BUTTON_11, BUTTON_12, BUTTON_13, BUTTON_14, BUTTON_15,
BUTTON_16, BUTTON_17, BUTTON_18, BUTTON_19, BUTTON_20,
BUTTON_21, BUTTON_22, BUTTON_23, BUTTON_24, BUTTON_25
} ButtonState;

void Analoge_Input(){
DAC_SetOutput(0);
ButtonState lastState = IDLE;

// Een array om bij te houden welke toetsen zijn ingedrukt (maximaal 25)
ButtonState pressedButtons[25] = {IDLE};
uint8_t pressedCount = 0;

// ====================================================================
// PARAFONIE PLANNING
//
// Huidige software:
// Monofoon
// Laatste note prioriteit 
// 1 DAC uitgang
// 1 gate uitgang
//
// Toekomst:
//
// bijvoorbeeld een MCP4728 externe DAC aangestuurd met I2C 
// 3 afzonderlijke gates, deze moeten nog gedefineerd worden in de MCC!
//
// ====================================================================

while (1) {
    // Een tijdelijke array om te kijken welke knoppen NU fysiek ingedrukt zijn
    uint8_t currentlyPressed[26] = {0};
    
    // Lees de fysieke status van ALLES
    if (OCT1_C_GetValue())  currentlyPressed[BUTTON_1] = 1;
    if (OCT1_Db_GetValue()) currentlyPressed[BUTTON_2] = 1;
    if (OCT1_D_GetValue())  currentlyPressed[BUTTON_3] = 1;
    if (OCT1_Eb_GetValue()) currentlyPressed[BUTTON_4] = 1;
    if (OCT1_E_GetValue())  currentlyPressed[BUTTON_5] = 1;
    if (OCT1_F_GetValue())  currentlyPressed[BUTTON_6] = 1;
    if (OCT1_Gb_GetValue()) currentlyPressed[BUTTON_7] = 1;
    if (OCT1_G_GetValue())  currentlyPressed[BUTTON_8] = 1;
    if (OCT1_Ab_GetValue()) currentlyPressed[BUTTON_9] = 1;
    if (OCT1_A_GetValue())  currentlyPressed[BUTTON_10] = 1;
    if (OCT1_Bb_GetValue()) currentlyPressed[BUTTON_11] = 1;
    if (OCT1_B_GetValue())  currentlyPressed[BUTTON_12] = 1;
    if (OCT2_C_GetValue())  currentlyPressed[BUTTON_13] = 1;
    if (OCT2_Db_GetValue()) currentlyPressed[BUTTON_14] = 1;
    if (OCT2_D_GetValue())  currentlyPressed[BUTTON_15] = 1;
    if (OCT2_Eb_GetValue()) currentlyPressed[BUTTON_16] = 1;
    if (OCT2_E_GetValue())  currentlyPressed[BUTTON_17] = 1;
    if (OCT2_F_GetValue())  currentlyPressed[BUTTON_18] = 1;
    if (OCT2_Gb_GetValue()) currentlyPressed[BUTTON_19] = 1;
    if (OCT2_G_GetValue())  currentlyPressed[BUTTON_20] = 1;
    if (OCT2_Ab_GetValue()) currentlyPressed[BUTTON_21] = 1;
    if (OCT2_A_GetValue())  currentlyPressed[BUTTON_22] = 1;
    if (OCT2_Bb_GetValue()) currentlyPressed[BUTTON_23] = 1;
    if (OCT2_B_GetValue())  currentlyPressed[BUTTON_24] = 1;
    if (OCT3_C_GetValue())  currentlyPressed[BUTTON_25] = 1;

    //Verwijder knoppen die zijn losgelaten
    for (int i = 0; i < pressedCount; i++) {
        if (!currentlyPressed[pressedButtons[i]]) {
            for (int j = i; j < pressedCount - 1; j++) {
                pressedButtons[j] = pressedButtons[j + 1];
            }
            pressedCount--;
            i--; 
        }
    }

    //Voeg knoppen toe die nieuw zijn ingedrukt
    for (int b = BUTTON_1; b <= BUTTON_25; b++) {
        if (currentlyPressed[b]) {
            uint8_t alAanwezig = 0;
            for (int i = 0; i < pressedCount; i++) {
                if (pressedButtons[i] == b) {
                    alAanwezig = 1;
                    break;
                }
            }
            if (!alAanwezig && pressedCount < 25) {
                pressedButtons[pressedCount] = b;
                pressedCount++;
            }
        }
    }

    //Bepaal de huidige state (laatst ingedrukte knop)
    ButtonState currentState = (pressedCount > 0) ? pressedButtons[pressedCount - 1] : IDLE; //condition ? value_if_true : value_if_false

    // DAC en gate
    if (currentState != lastState) {
        if (currentState != IDLE) {
            uint8_t buttonIndex = currentState - BUTTON_1; 
            DAC_value = 311 + buttonIndex * 25.85; 
            DAC_SetOutput(DAC_value << 6); 
            gate_pulse(); 
        } else {
            DAC_value = 0;
            DAC_SetOutput(DAC_value << 6);
            gate_SetLow();
        }
        lastState = currentState;
    }
}
}

void Digitale_Input(void) {
// TODO: Voeg hier eventueel de code voor digitale input toe, zie 2024/2025 documentatie input module voor meer informatie
while(1) {

}
}

