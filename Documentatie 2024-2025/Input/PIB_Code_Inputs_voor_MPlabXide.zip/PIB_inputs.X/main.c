 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h" 
#include <util/delay.h> 
uint16_t DAC_value = 0; 

int main(void) {
    SYSTEM_Initialize();

    if (schakelaar_GetValue()){
        Analoge_Input();
    }
    else{
        Digitale_Input();
    }
}

void DAC_SetOutput(uint16_t value) {
    DAC0.DATA = value;
}

void gate_pulse(void) {
    gate_SetLow();
    _delay_ms(10);
    gate_SetHigh();
}

typedef enum {
       IDLE,BUTTON_1, BUTTON_2, BUTTON_3, BUTTON_4, BUTTON_5,
            BUTTON_6, BUTTON_7, BUTTON_8, BUTTON_9, BUTTON_10,
            BUTTON_11, BUTTON_12, BUTTON_13, BUTTON_14, BUTTON_15,
            BUTTON_16, BUTTON_17, BUTTON_18, BUTTON_19, BUTTON_20,
            BUTTON_21, BUTTON_22, BUTTON_23, BUTTON_24, BUTTON_25
} ButtonState;

void Analoge_Input(){
    DAC_SetOutput(0);
    ButtonState currentState = IDLE;
    ButtonState lastState = IDLE;
     while (1) {
        // Detecteer welke knop wordt ingedrukt.
            if (OCT3_C_GetValue()) currentState = BUTTON_25;
            else if (OCT2_B_GetValue()) currentState = BUTTON_24;
            else if (OCT2_Bb_GetValue()) currentState = BUTTON_23;
            else if (OCT2_A_GetValue()) currentState = BUTTON_22;
            else if (OCT2_Ab_GetValue()) currentState = BUTTON_21;
            else if (OCT2_G_GetValue()) currentState = BUTTON_20;
            else if (OCT2_Gb_GetValue()) currentState = BUTTON_19;
            else if (OCT2_F_GetValue()) currentState = BUTTON_18;
            else if (OCT2_E_GetValue()) currentState = BUTTON_17;
            else if (OCT2_Eb_GetValue()) currentState = BUTTON_16;
            else if (OCT2_D_GetValue()) currentState = BUTTON_15;
            else if (OCT2_Db_GetValue()) currentState = BUTTON_14;
            else if (OCT2_C_GetValue()) currentState = BUTTON_13;
            else if (OCT1_B_GetValue()) currentState = BUTTON_12;
            else if (OCT1_Bb_GetValue()) currentState = BUTTON_11;
            else if (OCT1_A_GetValue()) currentState = BUTTON_10;
            else if (OCT1_Ab_GetValue()) currentState = BUTTON_9;
            else if (OCT1_G_GetValue()) currentState = BUTTON_8;
            else if (OCT1_Gb_GetValue()) currentState = BUTTON_7;
            else if (OCT1_F_GetValue()) currentState = BUTTON_6;
            else if (OCT1_E_GetValue()) currentState = BUTTON_5;
            else if (OCT1_Eb_GetValue()) currentState = BUTTON_4;
            else if (OCT1_D_GetValue()) currentState = BUTTON_3;
            else if (OCT1_Db_GetValue()) currentState = BUTTON_2;
            else if (OCT1_C_GetValue()) currentState = BUTTON_1;
            else currentState = IDLE;

            if (currentState != lastState) {
                if (currentState != IDLE) {
                    uint8_t buttonIndex = currentState - BUTTON_1; // Bereken index van de knop.
                    DAC_value = 311 + buttonIndex * 25.85; // Bereken de DAC-uitgang voor de toets.
                    DAC_SetOutput(DAC_value << 6); // Zet de DAC-uitgang.
                    gate_pulse(); // Geef een puls op de gate.
                } else {
                    DAC_value = 0;
                    DAC_SetOutput(DAC_value << 6);
                    gate_SetLow();
                }
                lastState = currentState;
            }
        }
}

void Digitale_Input(){
    //zet hier je code voor MIDI uitlezen
}

        
