/**
 * Generated Driver File
 * 
 * @file pins.c
 * 
 * @ingroup  pinsdriver
 * 
 * @brief This is generated driver implementation for pins. 
 *        This file provides implementations for pin APIs for all pins selected in the GUI.
 *
 * @version Driver Version 1.1.0
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#include "../pins.h"

static void (*DAC_InterruptHandler)(void);
static void (*OCT1_C_InterruptHandler)(void);
static void (*OCT1_Db_InterruptHandler)(void);
static void (*OCT1_D_InterruptHandler)(void);
static void (*OCT1_Eb_InterruptHandler)(void);
static void (*OCT1_E_InterruptHandler)(void);
static void (*OCT1_F_InterruptHandler)(void);
static void (*OCT1_Gb_InterruptHandler)(void);
static void (*OCT1_G_InterruptHandler)(void);
static void (*OCT1_Ab_InterruptHandler)(void);
static void (*OCT1_A_InterruptHandler)(void);
static void (*OCT1_Bb_InterruptHandler)(void);
static void (*OCT1_B_InterruptHandler)(void);
static void (*OCT2_C_InterruptHandler)(void);
static void (*OCT2_Db_InterruptHandler)(void);
static void (*OCT2_D_InterruptHandler)(void);
static void (*OCT2_Eb_InterruptHandler)(void);
static void (*OCT2_E_InterruptHandler)(void);
static void (*OCT2_F_InterruptHandler)(void);
static void (*OCT2_Gb_InterruptHandler)(void);
static void (*OCT2_G_InterruptHandler)(void);
static void (*OCT2_Ab_InterruptHandler)(void);
static void (*OCT2_A_InterruptHandler)(void);
static void (*OCT2_Bb_InterruptHandler)(void);
static void (*OCT2_B_InterruptHandler)(void);
static void (*OCT3_C_InterruptHandler)(void);
static void (*midi_InterruptHandler)(void);
static void (*gate_InterruptHandler)(void);
static void (*schakelaar_InterruptHandler)(void);

void PIN_MANAGER_Initialize()
{

  /* OUT Registers Initialization */
    PORTA.OUT = 0x0;
    PORTB.OUT = 0x0;
    PORTC.OUT = 0x0;
    PORTD.OUT = 0x0;
    PORTE.OUT = 0x0;
    PORTF.OUT = 0x0;

  /* DIR Registers Initialization */
    PORTA.DIR = 0x0;
    PORTB.DIR = 0x0;
    PORTC.DIR = 0x0;
    PORTD.DIR = 0xC0;
    PORTE.DIR = 0x8;
    PORTF.DIR = 0x0;

  /* PINxCTRL registers Initialization */
    PORTA.PIN0CTRL = 0x0;
    PORTA.PIN1CTRL = 0x0;
    PORTA.PIN2CTRL = 0x88;
    PORTA.PIN3CTRL = 0x88;
    PORTA.PIN4CTRL = 0x88;
    PORTA.PIN5CTRL = 0x88;
    PORTA.PIN6CTRL = 0x88;
    PORTA.PIN7CTRL = 0x88;
    PORTB.PIN0CTRL = 0x88;
    PORTB.PIN1CTRL = 0x88;
    PORTB.PIN2CTRL = 0x88;
    PORTB.PIN3CTRL = 0x88;
    PORTB.PIN4CTRL = 0x88;
    PORTB.PIN5CTRL = 0x88;
    PORTB.PIN6CTRL = 0x0;
    PORTB.PIN7CTRL = 0x0;
    PORTC.PIN0CTRL = 0x88;
    PORTC.PIN1CTRL = 0x88;
    PORTC.PIN2CTRL = 0x88;
    PORTC.PIN3CTRL = 0x88;
    PORTC.PIN4CTRL = 0x88;
    PORTC.PIN5CTRL = 0x88;
    PORTC.PIN6CTRL = 0x88;
    PORTC.PIN7CTRL = 0x88;
    PORTD.PIN0CTRL = 0x88;
    PORTD.PIN1CTRL = 0x88;
    PORTD.PIN2CTRL = 0x80;
    PORTD.PIN3CTRL = 0x80;
    PORTD.PIN4CTRL = 0x80;
    PORTD.PIN5CTRL = 0x0;
    PORTD.PIN6CTRL = 0x0;
    PORTD.PIN7CTRL = 0x0;
    PORTE.PIN0CTRL = 0x0;
    PORTE.PIN1CTRL = 0x0;
    PORTE.PIN2CTRL = 0x0;
    PORTE.PIN3CTRL = 0x0;
    PORTE.PIN4CTRL = 0x0;
    PORTE.PIN5CTRL = 0x0;
    PORTE.PIN6CTRL = 0x0;
    PORTE.PIN7CTRL = 0x0;
    PORTF.PIN0CTRL = 0x0;
    PORTF.PIN1CTRL = 0x0;
    PORTF.PIN2CTRL = 0x0;
    PORTF.PIN3CTRL = 0x0;
    PORTF.PIN4CTRL = 0x0;
    PORTF.PIN5CTRL = 0x0;
    PORTF.PIN6CTRL = 0x0;
    PORTF.PIN7CTRL = 0x0;

  /* PORTMUX Initialization */
    PORTMUX.ACROUTEA = 0x0;
    PORTMUX.CCLROUTEA = 0x0;
    PORTMUX.EVSYSROUTEA = 0x0;
    PORTMUX.SPIROUTEA = 0x0;
    PORTMUX.TCAROUTEA = 0x0;
    PORTMUX.TCBROUTEA = 0x0;
    PORTMUX.TCDROUTEA = 0x0;
    PORTMUX.TWIROUTEA = 0x0;
    PORTMUX.USARTROUTEA = 0x0;
    PORTMUX.USARTROUTEB = 0x0;
    PORTMUX.ZCDROUTEA = 0x0;

  // register default ISC callback functions at runtime; use these methods to register a custom function
    DAC_SetInterruptHandler(DAC_DefaultInterruptHandler);
    OCT1_C_SetInterruptHandler(OCT1_C_DefaultInterruptHandler);
    OCT1_Db_SetInterruptHandler(OCT1_Db_DefaultInterruptHandler);
    OCT1_D_SetInterruptHandler(OCT1_D_DefaultInterruptHandler);
    OCT1_Eb_SetInterruptHandler(OCT1_Eb_DefaultInterruptHandler);
    OCT1_E_SetInterruptHandler(OCT1_E_DefaultInterruptHandler);
    OCT1_F_SetInterruptHandler(OCT1_F_DefaultInterruptHandler);
    OCT1_Gb_SetInterruptHandler(OCT1_Gb_DefaultInterruptHandler);
    OCT1_G_SetInterruptHandler(OCT1_G_DefaultInterruptHandler);
    OCT1_Ab_SetInterruptHandler(OCT1_Ab_DefaultInterruptHandler);
    OCT1_A_SetInterruptHandler(OCT1_A_DefaultInterruptHandler);
    OCT1_Bb_SetInterruptHandler(OCT1_Bb_DefaultInterruptHandler);
    OCT1_B_SetInterruptHandler(OCT1_B_DefaultInterruptHandler);
    OCT2_C_SetInterruptHandler(OCT2_C_DefaultInterruptHandler);
    OCT2_Db_SetInterruptHandler(OCT2_Db_DefaultInterruptHandler);
    OCT2_D_SetInterruptHandler(OCT2_D_DefaultInterruptHandler);
    OCT2_Eb_SetInterruptHandler(OCT2_Eb_DefaultInterruptHandler);
    OCT2_E_SetInterruptHandler(OCT2_E_DefaultInterruptHandler);
    OCT2_F_SetInterruptHandler(OCT2_F_DefaultInterruptHandler);
    OCT2_Gb_SetInterruptHandler(OCT2_Gb_DefaultInterruptHandler);
    OCT2_G_SetInterruptHandler(OCT2_G_DefaultInterruptHandler);
    OCT2_Ab_SetInterruptHandler(OCT2_Ab_DefaultInterruptHandler);
    OCT2_A_SetInterruptHandler(OCT2_A_DefaultInterruptHandler);
    OCT2_Bb_SetInterruptHandler(OCT2_Bb_DefaultInterruptHandler);
    OCT2_B_SetInterruptHandler(OCT2_B_DefaultInterruptHandler);
    OCT3_C_SetInterruptHandler(OCT3_C_DefaultInterruptHandler);
    midi_SetInterruptHandler(midi_DefaultInterruptHandler);
    gate_SetInterruptHandler(gate_DefaultInterruptHandler);
    schakelaar_SetInterruptHandler(schakelaar_DefaultInterruptHandler);
}

/**
  Allows selecting an interrupt handler for DAC at application runtime
*/
void DAC_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    DAC_InterruptHandler = interruptHandler;
}

void DAC_DefaultInterruptHandler(void)
{
    // add your DAC interrupt custom code
    // or set custom function using DAC_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT1_C at application runtime
*/
void OCT1_C_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT1_C_InterruptHandler = interruptHandler;
}

void OCT1_C_DefaultInterruptHandler(void)
{
    // add your OCT1_C interrupt custom code
    // or set custom function using OCT1_C_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT1_Db at application runtime
*/
void OCT1_Db_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT1_Db_InterruptHandler = interruptHandler;
}

void OCT1_Db_DefaultInterruptHandler(void)
{
    // add your OCT1_Db interrupt custom code
    // or set custom function using OCT1_Db_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT1_D at application runtime
*/
void OCT1_D_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT1_D_InterruptHandler = interruptHandler;
}

void OCT1_D_DefaultInterruptHandler(void)
{
    // add your OCT1_D interrupt custom code
    // or set custom function using OCT1_D_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT1_Eb at application runtime
*/
void OCT1_Eb_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT1_Eb_InterruptHandler = interruptHandler;
}

void OCT1_Eb_DefaultInterruptHandler(void)
{
    // add your OCT1_Eb interrupt custom code
    // or set custom function using OCT1_Eb_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT1_E at application runtime
*/
void OCT1_E_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT1_E_InterruptHandler = interruptHandler;
}

void OCT1_E_DefaultInterruptHandler(void)
{
    // add your OCT1_E interrupt custom code
    // or set custom function using OCT1_E_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT1_F at application runtime
*/
void OCT1_F_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT1_F_InterruptHandler = interruptHandler;
}

void OCT1_F_DefaultInterruptHandler(void)
{
    // add your OCT1_F interrupt custom code
    // or set custom function using OCT1_F_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT1_Gb at application runtime
*/
void OCT1_Gb_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT1_Gb_InterruptHandler = interruptHandler;
}

void OCT1_Gb_DefaultInterruptHandler(void)
{
    // add your OCT1_Gb interrupt custom code
    // or set custom function using OCT1_Gb_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT1_G at application runtime
*/
void OCT1_G_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT1_G_InterruptHandler = interruptHandler;
}

void OCT1_G_DefaultInterruptHandler(void)
{
    // add your OCT1_G interrupt custom code
    // or set custom function using OCT1_G_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT1_Ab at application runtime
*/
void OCT1_Ab_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT1_Ab_InterruptHandler = interruptHandler;
}

void OCT1_Ab_DefaultInterruptHandler(void)
{
    // add your OCT1_Ab interrupt custom code
    // or set custom function using OCT1_Ab_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT1_A at application runtime
*/
void OCT1_A_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT1_A_InterruptHandler = interruptHandler;
}

void OCT1_A_DefaultInterruptHandler(void)
{
    // add your OCT1_A interrupt custom code
    // or set custom function using OCT1_A_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT1_Bb at application runtime
*/
void OCT1_Bb_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT1_Bb_InterruptHandler = interruptHandler;
}

void OCT1_Bb_DefaultInterruptHandler(void)
{
    // add your OCT1_Bb interrupt custom code
    // or set custom function using OCT1_Bb_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT1_B at application runtime
*/
void OCT1_B_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT1_B_InterruptHandler = interruptHandler;
}

void OCT1_B_DefaultInterruptHandler(void)
{
    // add your OCT1_B interrupt custom code
    // or set custom function using OCT1_B_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT2_C at application runtime
*/
void OCT2_C_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT2_C_InterruptHandler = interruptHandler;
}

void OCT2_C_DefaultInterruptHandler(void)
{
    // add your OCT2_C interrupt custom code
    // or set custom function using OCT2_C_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT2_Db at application runtime
*/
void OCT2_Db_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT2_Db_InterruptHandler = interruptHandler;
}

void OCT2_Db_DefaultInterruptHandler(void)
{
    // add your OCT2_Db interrupt custom code
    // or set custom function using OCT2_Db_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT2_D at application runtime
*/
void OCT2_D_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT2_D_InterruptHandler = interruptHandler;
}

void OCT2_D_DefaultInterruptHandler(void)
{
    // add your OCT2_D interrupt custom code
    // or set custom function using OCT2_D_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT2_Eb at application runtime
*/
void OCT2_Eb_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT2_Eb_InterruptHandler = interruptHandler;
}

void OCT2_Eb_DefaultInterruptHandler(void)
{
    // add your OCT2_Eb interrupt custom code
    // or set custom function using OCT2_Eb_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT2_E at application runtime
*/
void OCT2_E_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT2_E_InterruptHandler = interruptHandler;
}

void OCT2_E_DefaultInterruptHandler(void)
{
    // add your OCT2_E interrupt custom code
    // or set custom function using OCT2_E_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT2_F at application runtime
*/
void OCT2_F_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT2_F_InterruptHandler = interruptHandler;
}

void OCT2_F_DefaultInterruptHandler(void)
{
    // add your OCT2_F interrupt custom code
    // or set custom function using OCT2_F_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT2_Gb at application runtime
*/
void OCT2_Gb_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT2_Gb_InterruptHandler = interruptHandler;
}

void OCT2_Gb_DefaultInterruptHandler(void)
{
    // add your OCT2_Gb interrupt custom code
    // or set custom function using OCT2_Gb_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT2_G at application runtime
*/
void OCT2_G_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT2_G_InterruptHandler = interruptHandler;
}

void OCT2_G_DefaultInterruptHandler(void)
{
    // add your OCT2_G interrupt custom code
    // or set custom function using OCT2_G_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT2_Ab at application runtime
*/
void OCT2_Ab_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT2_Ab_InterruptHandler = interruptHandler;
}

void OCT2_Ab_DefaultInterruptHandler(void)
{
    // add your OCT2_Ab interrupt custom code
    // or set custom function using OCT2_Ab_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT2_A at application runtime
*/
void OCT2_A_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT2_A_InterruptHandler = interruptHandler;
}

void OCT2_A_DefaultInterruptHandler(void)
{
    // add your OCT2_A interrupt custom code
    // or set custom function using OCT2_A_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT2_Bb at application runtime
*/
void OCT2_Bb_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT2_Bb_InterruptHandler = interruptHandler;
}

void OCT2_Bb_DefaultInterruptHandler(void)
{
    // add your OCT2_Bb interrupt custom code
    // or set custom function using OCT2_Bb_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT2_B at application runtime
*/
void OCT2_B_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT2_B_InterruptHandler = interruptHandler;
}

void OCT2_B_DefaultInterruptHandler(void)
{
    // add your OCT2_B interrupt custom code
    // or set custom function using OCT2_B_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for OCT3_C at application runtime
*/
void OCT3_C_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    OCT3_C_InterruptHandler = interruptHandler;
}

void OCT3_C_DefaultInterruptHandler(void)
{
    // add your OCT3_C interrupt custom code
    // or set custom function using OCT3_C_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for midi at application runtime
*/
void midi_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    midi_InterruptHandler = interruptHandler;
}

void midi_DefaultInterruptHandler(void)
{
    // add your midi interrupt custom code
    // or set custom function using midi_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for gate at application runtime
*/
void gate_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    gate_InterruptHandler = interruptHandler;
}

void gate_DefaultInterruptHandler(void)
{
    // add your gate interrupt custom code
    // or set custom function using gate_SetInterruptHandler()
}
/**
  Allows selecting an interrupt handler for schakelaar at application runtime
*/
void schakelaar_SetInterruptHandler(void (* interruptHandler)(void)) 
{
    schakelaar_InterruptHandler = interruptHandler;
}

void schakelaar_DefaultInterruptHandler(void)
{
    // add your schakelaar interrupt custom code
    // or set custom function using schakelaar_SetInterruptHandler()
}
ISR(PORTA_PORT_vect)
{ 
    // Call the interrupt handler for the callback registered at runtime
    if(VPORTA.INTFLAGS & PORT_INT2_bm)
    {
       OCT1_C_InterruptHandler(); 
    }
    if(VPORTA.INTFLAGS & PORT_INT3_bm)
    {
       OCT1_Db_InterruptHandler(); 
    }
    if(VPORTA.INTFLAGS & PORT_INT4_bm)
    {
       OCT1_D_InterruptHandler(); 
    }
    if(VPORTA.INTFLAGS & PORT_INT5_bm)
    {
       OCT1_Eb_InterruptHandler(); 
    }
    if(VPORTA.INTFLAGS & PORT_INT6_bm)
    {
       OCT1_E_InterruptHandler(); 
    }
    if(VPORTA.INTFLAGS & PORT_INT7_bm)
    {
       OCT1_F_InterruptHandler(); 
    }
    /* Clear interrupt flags */
    VPORTA.INTFLAGS = 0xff;
}

ISR(PORTB_PORT_vect)
{ 
    // Call the interrupt handler for the callback registered at runtime
    if(VPORTB.INTFLAGS & PORT_INT0_bm)
    {
       OCT1_Gb_InterruptHandler(); 
    }
    if(VPORTB.INTFLAGS & PORT_INT1_bm)
    {
       OCT1_G_InterruptHandler(); 
    }
    if(VPORTB.INTFLAGS & PORT_INT2_bm)
    {
       OCT1_Ab_InterruptHandler(); 
    }
    if(VPORTB.INTFLAGS & PORT_INT3_bm)
    {
       OCT1_A_InterruptHandler(); 
    }
    if(VPORTB.INTFLAGS & PORT_INT4_bm)
    {
       OCT1_Bb_InterruptHandler(); 
    }
    if(VPORTB.INTFLAGS & PORT_INT5_bm)
    {
       OCT1_B_InterruptHandler(); 
    }
    /* Clear interrupt flags */
    VPORTB.INTFLAGS = 0xff;
}

ISR(PORTC_PORT_vect)
{ 
    // Call the interrupt handler for the callback registered at runtime
    if(VPORTC.INTFLAGS & PORT_INT0_bm)
    {
       OCT2_C_InterruptHandler(); 
    }
    if(VPORTC.INTFLAGS & PORT_INT1_bm)
    {
       OCT2_Db_InterruptHandler(); 
    }
    if(VPORTC.INTFLAGS & PORT_INT2_bm)
    {
       OCT2_D_InterruptHandler(); 
    }
    if(VPORTC.INTFLAGS & PORT_INT3_bm)
    {
       OCT2_Eb_InterruptHandler(); 
    }
    if(VPORTC.INTFLAGS & PORT_INT4_bm)
    {
       OCT2_E_InterruptHandler(); 
    }
    if(VPORTC.INTFLAGS & PORT_INT5_bm)
    {
       OCT2_F_InterruptHandler(); 
    }
    if(VPORTC.INTFLAGS & PORT_INT6_bm)
    {
       OCT2_Gb_InterruptHandler(); 
    }
    if(VPORTC.INTFLAGS & PORT_INT7_bm)
    {
       OCT2_G_InterruptHandler(); 
    }
    /* Clear interrupt flags */
    VPORTC.INTFLAGS = 0xff;
}

ISR(PORTD_PORT_vect)
{ 
    // Call the interrupt handler for the callback registered at runtime
    if(VPORTD.INTFLAGS & PORT_INT6_bm)
    {
       DAC_InterruptHandler(); 
    }
    if(VPORTD.INTFLAGS & PORT_INT0_bm)
    {
       OCT2_Ab_InterruptHandler(); 
    }
    if(VPORTD.INTFLAGS & PORT_INT1_bm)
    {
       OCT2_A_InterruptHandler(); 
    }
    if(VPORTD.INTFLAGS & PORT_INT2_bm)
    {
       OCT2_Bb_InterruptHandler(); 
    }
    if(VPORTD.INTFLAGS & PORT_INT3_bm)
    {
       OCT2_B_InterruptHandler(); 
    }
    if(VPORTD.INTFLAGS & PORT_INT4_bm)
    {
       OCT3_C_InterruptHandler(); 
    }
    if(VPORTD.INTFLAGS & PORT_INT5_bm)
    {
       midi_InterruptHandler(); 
    }
    if(VPORTD.INTFLAGS & PORT_INT7_bm)
    {
       gate_InterruptHandler(); 
    }
    /* Clear interrupt flags */
    VPORTD.INTFLAGS = 0xff;
}

ISR(PORTE_PORT_vect)
{ 
    // Call the interrupt handler for the callback registered at runtime
    if(VPORTE.INTFLAGS & PORT_INT3_bm)
    {
       schakelaar_InterruptHandler(); 
    }
    /* Clear interrupt flags */
    VPORTE.INTFLAGS = 0xff;
}

ISR(PORTF_PORT_vect)
{ 
    /* Clear interrupt flags */
    VPORTF.INTFLAGS = 0xff;
}

/**
 End of File
*/